﻿namespace Unity.XR.PXR
{
    public enum PackageControlEnum
    {
        PACKAGE_SILENCE_INSTALL=0,
        PACKAGE_SILENCE_UNINSTALL=1
    }
}