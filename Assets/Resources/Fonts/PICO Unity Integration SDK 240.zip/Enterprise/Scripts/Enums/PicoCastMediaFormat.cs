﻿namespace Unity.XR.PXR
{
    public class PicoCastMediaFormat
    {
        public int bitrate = -1;//kb
    }
}